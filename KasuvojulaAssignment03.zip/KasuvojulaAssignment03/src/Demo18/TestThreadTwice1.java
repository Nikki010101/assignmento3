package Demo18;

public class TestThreadTwice1 extends Thread{  
	 public void run(){  
	   System.out.println("running...");  
	 }  }
