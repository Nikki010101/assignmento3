package Demo19;

public class Demo19 {
	 public static void main(String[] args) {
	        MyThread myThread = new MyThread();
	        myThread.start();
	        MyRunnable myRunnable = new MyRunnable();
	        Thread thread = new Thread(myRunnable);
	        thread.start();
}}
class MyThread extends Thread {
    public void run() {
        System.out.println("MyThread is running......");
    }
}
class MyRunnable implements Runnable {
    public void run() {
        System.out.println("MyRunnable is running");
    }
}




