package Demo08;

public class Demo08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=5;
try {
	if(x!=5)
	{
		System.out.println("Try block");
	}
}finally {
	if(x==5)
	{
		System.out.println("Finally block");
}
	}

}}
