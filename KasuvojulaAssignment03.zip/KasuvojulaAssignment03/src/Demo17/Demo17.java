package Demo17;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class Demo17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Map<String, String> empName = new HashMap<String, String>();   
          empName.put("Sam Hanks", "New york");   
          empName.put("Will Smith", "LA");   
          empName.put("Scarlett", "Chicago");   
          Iterator iterator = empName.keySet().iterator();   
//          while (iterator.hasNext()) {   
//              System.out.println(empName.get(iterator.next()));   
//              // adding an element to Map   
//              // exception will be thrown on next call   
//              // of next() method.   
//              empName.put("Istanbul", "Turkey");   
//          }   // ------------------------------------Throws error,
          //The Fail Fast iterator throws a ConcurrentModificationException if a collection is modified while iterating over it.
          CopyOnWriteArrayList<Integer> list   
          = new CopyOnWriteArrayList<Integer>(new Integer[] { 1,2,3,4 });   
      Iterator itr = list.iterator();   
      while (itr.hasNext()) {   
          Integer i = (Integer)itr.next();   
          System.out.println(i);   
          if (i == 2)   
              list.add(5); // It will not be printed  
          //This means it has created a separate copy of the collection  
      }   
	}

}
