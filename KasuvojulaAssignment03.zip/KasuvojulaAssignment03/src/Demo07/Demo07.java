package Demo07;

public class Demo07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
 class Dog{
	private String name;

//	public final Dog(String name) {
//		super();
//		this.name = name;
//	}                             //showing error as invalid modifier
	public  Dog(String name) {
		super();
		this.name = name;
	}
	
}
