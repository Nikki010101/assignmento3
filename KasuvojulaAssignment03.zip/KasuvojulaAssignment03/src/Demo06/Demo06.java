package Demo06;

public class Demo06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "Hello";
		String str2 = str1.concat(" World");
		System.out.println(str1); // Output: Hello
		System.out.println(str2); // Output: Hello World

		StringBuffer sb1 = new StringBuffer("Hello");
		sb1.append(" World");
		System.out.println(sb1);
	}

}
