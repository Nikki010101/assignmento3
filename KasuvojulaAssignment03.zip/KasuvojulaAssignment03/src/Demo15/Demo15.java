package Demo15;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class Demo15 {
	
		   public static void main(String args[])
		   {
		       //----------HashTable Declaration -------------------------
		       Hashtable<String,Integer> ht=new Hashtable<String,Integer>();
		       ht.put("Apple",3);
		       ht.put("Bat",2);
		       ht.put("Cat",10);
		      // ht.put("dog", null); ---------Null values are not taken in HashTable
		       System.out.println("-------------HashTable Data--------------");
		       for (Map.Entry m:ht.entrySet()) {
		           System.out.println(m.getKey()+" "+m.getValue());
		       }

		       //----------------HashMap Declaration--------------------------------
		       HashMap<String,Integer> hm=new HashMap<String,Integer>();
		       hm.put("Honey",31);
		       hm.put("Ice",20);
		       hm.put("Jug",1);
		       hm.put("dog", null);
		       System.out.println("-----------HashMap Data-----------");
		       for (Map.Entry m:hm.entrySet()) {
		           System.out.println(m.getKey()+" "+m.getValue());
		       }
		   }
		}

