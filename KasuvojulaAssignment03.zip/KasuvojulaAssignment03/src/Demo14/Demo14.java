package Demo14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Demo14 {
	static List<String> list1 = Collections.synchronizedList(new ArrayList<>());
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = Collections.synchronizedList(new ArrayList<>());
		
		synchronized (list) {
		    list.add("Inside class");
		    
		}
		list.add("synchronized wrapper");
		System.out.println(list);
		addItem("outside class");
	}
	static void addItem(String item) {
	    synchronized (list1) {
	    	list1.add(item);
	    	System.out.println(list1);
	    }
	}

}
