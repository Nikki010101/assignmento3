package Demo03;

public class Car extends Vehicle{

	@Override
	public Car start() {
		System.out.println("Car started");
		return new Car();
	}

}
