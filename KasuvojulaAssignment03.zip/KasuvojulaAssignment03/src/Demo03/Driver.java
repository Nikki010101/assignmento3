package Demo03;

public class Driver {
	
	    public static void main(String[] args) {
	        Vehicle vehicle = new Vehicle();
	        Vehicle car = new Car();
	        
	        vehicle.start(); 
	        car.start();    
	    }
	}

