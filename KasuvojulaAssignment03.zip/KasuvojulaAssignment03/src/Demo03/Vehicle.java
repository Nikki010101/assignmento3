package Demo03;

public class Vehicle {
	
	    public Vehicle start() {
	        System.out.println("Vehicle started");
	        return new Vehicle();
	    }
	}

