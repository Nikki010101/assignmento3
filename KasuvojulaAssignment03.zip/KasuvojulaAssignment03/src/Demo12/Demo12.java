package Demo12;

public class Demo12 {
	public static final int num = 10;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  printMessage();
		  
		 // num=20; --------------Final cannot be assigned
		  try {
			    if(num==20) {
			    	System.out.println("catch block");
			    }
			}
			catch (Exception e) {
			    // exception handling
			}
			finally {
				if(num==10) {
			    	System.out.println("finally block");
			    }
			}
		 
		  
		  	}
	  public final static void printMessage() {
	        System.out.println("Hello World");
	    }
	  protected void finalize() throws Throwable {
	        // This method is for cleanup tasks
	       System.out.println("Finalise method");
	    }


}
