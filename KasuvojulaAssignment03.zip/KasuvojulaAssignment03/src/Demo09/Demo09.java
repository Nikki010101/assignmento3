package Demo09;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Demo09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (FileReader fileReader = new FileReader("filename.txt");
			     BufferedReader bufferedReader = new BufferedReader(fileReader)) {
			    String line;
			    while ((line = bufferedReader.readLine()) != null) {
			        System.out.println(line);
			    }
			} catch (IOException e) {
			    System.err.println("Error reading file: " + e.getMessage());
			}
		
	}

}
