package Demo04;

public class Demo04 {
	public static void main(String[] args) {
		Subclass s=new Subclass();
		s.works();
	}
	    private void run() {
	        System.out.println("This is a private.");
	    }
	    
	    public static void start() {
	        System.out.println("This is a static.");
	    }
	    public void works() {
	    	System.out.println("This is public");
	    }
	    
	}

	class Subclass extends Demo04 {

		@Override
		public void works() {
			// TODO Auto-generated method stub
			super.works();
		}
	    // override private method
//	    @Override
//	    private void run() {
//	        System.out.println("This is an overridden private.");
//	    }
//	    
//	    //override static method
//	    @Override
//	    public static void start() {
//	        System.out.println("This is an overridden static.");
//	    }
		// The above code is throwing errors as the methods are private and static.
		
	}


