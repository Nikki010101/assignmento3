package Demo05;

public class Demo05 {
	// StringBuffer
	public static void main(String[] args) {
		StringBuffer n1 = new StringBuffer("Hey");
		n1.append(" ");
		n1.append("all");
		n1.insert(3, ",");
		System.out.println(n1.toString()); 

		// StringBuilder
		StringBuilder n2 = new StringBuilder("Hey");
		n2.append(" ");
		n2.append("all");
		n2.insert(3, ",");
		System.out.println(n2.toString()); 
		// StringBuffer in a multithreaded environment
		StringBuffer n3 = new StringBuffer("Hey");
		synchronized(n3) {
			n3.append(" ");
			n3.append("all");
			n3.insert(3, ",");
		}
		System.out.println(n3.toString());
	}
	

}
