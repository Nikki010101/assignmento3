package Demo10;

import java.io.IOException;

public class Demo10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub}
		
	}
		class Superclass {
		    public void method() throws IOException {
		       
		    }
		}
		
		class Subclass extends Superclass {
		    // This is not allowed: the subclass method cannot remove the declared exception
//		    public void method() {
//		        
//		    }
//		    
//		    // This is allowed: the subclass method can declare the same exception or a subclass of it
//		    public void method() throws FileNotFoundException {
//		       
//		    }
//		    
//		    // This is also allowed: the subclass method can declare multiple exceptions
//		    public void method() throws IOException, InterruptedException {
//		        
//		    }
			 //This is not allowed, as it would violate the rule that the subclass method cannot declare
			 //fewer exceptions than the superclass method.
			
		}
	}


