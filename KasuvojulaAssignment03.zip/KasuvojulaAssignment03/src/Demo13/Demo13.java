package Demo13;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
public class Demo13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

		        Vector<String> v = new Vector<>();
		        ArrayList<String> a = new ArrayList<>();

		        // Adding elements to the Vector and the ArrayList
		        v.add("apple");
		        a.add("apple");
		        v.add("banana");
		        a.add("banana");

		       
		        // Accessing elements in the Vector and the ArrayList
		        System.out.println("index 1: " + v.get(1));
		        System.out.println("index 1: " + a.get(1));

		        v.add("cherry");
		        a.add("cherry");
		        // Removing an element from the Vector and the ArrayList
		        v.remove(1);
		        a.remove(1);
		        // Displaying the contents of the Vector and the ArrayList
		        System.out.println("removing element at index 1: " + v);
		        System.out.println("removing element at index 1: " + a);
		    }
		}
		
	


